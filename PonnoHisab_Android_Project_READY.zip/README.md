# পণ্য হিসাব — Android APK Project

এই অ্যাপের প্রথম সংস্করণে আছে:
- Username + Password login (Firebase Authentication)
- যেকোনো ফোনে একই অ্যাকাউন্টে লগইন
- পণ্যের বিবরণ, ছবি, পরিমাপ, দাম
- স্বয়ংক্রিয় মোট টাকা = পরিমাপ × দাম
- সর্বমোট
- Cloud Firestore-এ হিসাব সংরক্ষণ
- Firebase Storage-এ পণ্যের ছবি সংরক্ষণ

## Firebase সেটআপ
1. Firebase Console-এ একটি project তৈরি করুন।
2. Android app যোগ করুন, package name: `com.example.ponnohisab`
3. `google-services.json` ডাউনলোড করে `app/` ফোল্ডারে রাখুন।
4. Authentication → Sign-in method → Email/Password চালু করুন।
5. Firestore Database তৈরি করুন।
6. Storage চালু করুন।
7. নিচের rules বসান (প্রয়োজনে Firebase Console-এ):
   - Firestore: `firestore.rules`
   - Storage: `storage.rules`

## Username
Firebase Authentication email চায়। এই অ্যাপে username হিসেবে ব্যবহার করতে চাইলে username-কে একটি নির্দিষ্ট email format-এ রূপান্তর করা যায়। এই starter version-এ login screen email/password ব্যবহার করে।

পরবর্তী ধাপে চাইলে username-only login, password reset, profile, date-wise reports, PDF/Excel export যোগ করা যাবে।
