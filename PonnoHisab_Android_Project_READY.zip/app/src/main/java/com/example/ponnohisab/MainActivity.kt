package com.example.ponnohisab

import android.app.*
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import java.util.Locale

data class Product(
    var id: String = "",
    var description: String = "",
    var measurement: Double = 0.0,
    var price: Double = 0.0,
    var imageUrl: String = ""
) {
    fun total() = measurement * price
}

class MainActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var storage: FirebaseStorage
    private var selectedImage: Uri? = null
    private val products = mutableListOf<Product>()
    private lateinit var adapter: ProductAdapter
    private lateinit var totalText: TextView
    private lateinit var list: RecyclerView

    private val pickImage = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        selectedImage = uri
        Toast.makeText(this, if (uri != null) "ছবি নেওয়া হয়েছে" else "ছবি নির্বাচন বাতিল", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()
        storage = FirebaseStorage.getInstance()

        if (auth.currentUser == null) showLogin() else showHome()
    }

    private fun showLogin() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 70, 40, 40)
        }
        val title = TextView(this).apply {
            text = "📦 পণ্য হিসাব"
            textSize = 30f
            setPadding(0, 0, 0, 30)
        }
        val email = EditText(this).apply { hint = "Username / Email"; inputType = 33 }
        val pass = EditText(this).apply { hint = "Password"; inputType = 129 }
        val login = Button(this).apply { text = "লগইন" }
        val signup = Button(this).apply { text = "নতুন অ্যাকাউন্ট তৈরি" }
        box.addView(title); box.addView(email); box.addView(pass); box.addView(login); box.addView(signup)
        setContentView(box)

        login.setOnClickListener {
            val e = email.text.toString().trim()
            val p = pass.text.toString()
            if (e.isBlank() || p.isBlank()) { toast("Username/Email ও Password দিন"); return@setOnClickListener }
            auth.signInWithEmailAndPassword(e, p).addOnSuccessListener { showHome() }
                .addOnFailureListener { toast("লগইন হয়নি: ${it.message}") }
        }
        signup.setOnClickListener {
            val e = email.text.toString().trim()
            val p = pass.text.toString()
            if (e.isBlank() || p.length < 6) { toast("Email দিন এবং Password কমপক্ষে ৬ অক্ষরের দিন"); return@setOnClickListener }
            auth.createUserWithEmailAndPassword(e, p).addOnSuccessListener {
                toast("অ্যাকাউন্ট তৈরি হয়েছে"); showHome()
            }.addOnFailureListener { toast("অ্যাকাউন্ট তৈরি হয়নি: ${it.message}") }
        }
    }

    private fun showHome() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 20, 20, 20) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val title = TextView(this).apply { text = "📦 পণ্য হিসাব"; textSize = 26f; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        val logout = Button(this).apply { text = "লগআউট" }
        bar.addView(title); bar.addView(logout); root.addView(bar)

        val add = Button(this).apply { text = "＋ নতুন পণ্য যোগ করুন" }
        root.addView(add)

        list = RecyclerView(this).apply { layoutManager = LinearLayoutManager(this@MainActivity) }
        adapter = ProductAdapter(products) { loadProducts() }
        list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        totalText = TextView(this).apply { textSize = 20f; setPadding(0, 15, 0, 15) }
        root.addView(totalText)
        setContentView(root)

        add.setOnClickListener { showAddDialog() }
        logout.setOnClickListener { auth.signOut(); showLogin() }
        loadProducts()
    }

    private fun loadProducts() {
        val uid = auth.currentUser?.uid ?: return
        db.collection("users").document(uid).collection("products")
            .get().addOnSuccessListener { snap ->
                products.clear()
                snap.documents.forEach { d ->
                    products.add(Product(
                        d.id,
                        d.getString("description") ?: "",
                        d.getDouble("measurement") ?: 0.0,
                        d.getDouble("price") ?: 0.0,
                        d.getString("imageUrl") ?: ""
                    ))
                }
                adapter.notifyDataSetChanged()
                updateTotal()
            }.addOnFailureListener { toast("ডাটা লোড হয়নি: ${it.message}") }
    }

    private fun updateTotal() {
        val sum = products.sumOf { it.total() }
        totalText.text = "💰 সর্বমোট: ৳${String.format(Locale.US, "%.2f", sum)}"
    }

    private fun showAddDialog() {
        selectedImage = null
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 10, 20, 10) }
        val desc = EditText(this).apply { hint = "পণ্যের বিবরণ" }
        val measure = EditText(this).apply { hint = "পণ্যের পরিমাপ"; inputType = 2 }
        val price = EditText(this).apply { hint = "পণ্যের দাম"; inputType = 2 }
        val photo = Button(this).apply { text = "📷 পণ্যের ছবি নির্বাচন" }
        box.addView(desc); box.addView(measure); box.addView(price); box.addView(photo)
        photo.setOnClickListener { pickImage.launch("image/*") }

        AlertDialog.Builder(this).setTitle("নতুন পণ্য").setView(box)
            .setNegativeButton("বাতিল", null)
            .setPositiveButton("সেভ", null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val m = measure.text.toString().toDoubleOrNull()
                        val p = price.text.toString().toDoubleOrNull()
                        if (desc.text.isBlank() || m == null || p == null) { toast("সব তথ্য ঠিকভাবে দিন"); return@setOnClickListener }
                        saveProduct(desc.text.toString(), m, p, dialog)
                    }
                }
                dialog.show()
            }
    }

    private fun saveProduct(desc: String, measure: Double, price: Double, dialog: Dialog) {
        val uid = auth.currentUser?.uid ?: return
        val ref = db.collection("users").document(uid).collection("products").document()
        fun save(url: String) {
            ref.set(mapOf("description" to desc, "measurement" to measure, "price" to price, "imageUrl" to url))
                .addOnSuccessListener { dialog.dismiss(); loadProducts(); toast("পণ্য সেভ হয়েছে") }
                .addOnFailureListener { toast("সেভ হয়নি: ${it.message}") }
        }
        val uri = selectedImage
        if (uri == null) save("") else {
            val imageRef = storage.reference.child("users/$uid/products/${ref.id}.jpg")
            imageRef.putFile(uri).continueWithTask { imageRef.downloadUrl }
                .addOnSuccessListener { save(it.toString()) }
                .addOnFailureListener { toast("ছবি আপলোড হয়নি: ${it.message}") }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

class ProductAdapter(
    private val items: List<Product>,
    private val refresh: () -> Unit
) : RecyclerView.Adapter<ProductAdapter.VH>() {
    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val text: TextView = v as TextView
    }
    override fun onCreateViewHolder(p: android.view.ViewGroup, t: Int): VH {
        val tv = TextView(p.context).apply { textSize = 17f; setPadding(20, 25, 20, 25) }
        return VH(tv)
    }
    override fun getItemCount() = items.size
    override fun onBindViewHolder(h: VH, pos: Int) {
        val x = items[pos]
        h.text.text = "${pos + 1}. ${x.description}\nপরিমাপ: ${x.measurement}   দাম: ৳${x.price}\nমোট: ৳${x.total()}"
    }
}
